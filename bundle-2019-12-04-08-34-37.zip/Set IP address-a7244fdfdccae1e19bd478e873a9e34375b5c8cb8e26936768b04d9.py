def handler(context, inputs):
    
    ipAddress = inputs["customProperties"]["ipAddress"]
    outputs = {}
    
    outputs["customProperties"] = inputs["customProperties"]
    outputs["addresses"] = [[ipAddress]]
    outputs["networkSelectionIds"] = inputs["networkSelectionIds"]
    
    return outputs
