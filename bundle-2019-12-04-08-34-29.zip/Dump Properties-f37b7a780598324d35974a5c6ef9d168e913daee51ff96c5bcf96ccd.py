def handler(context, inputs):
   
    print ("Inputs")
    for key, value in inputs.items():
        print ("["+str(key)+"] ["+str(value)+"]")
    